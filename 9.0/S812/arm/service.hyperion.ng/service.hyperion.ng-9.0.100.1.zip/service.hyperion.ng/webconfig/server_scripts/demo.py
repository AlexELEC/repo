#!/usr/bin/env python

print ("hello world");


